-- TABLA FAMILIA: => Contiene las familias a las que pertenecen los productos, 
-- como por ejemplo ordenadores, impresoras,etc.

CREATE TABLE FAMILIA(
    Codfamilia NUMBER(3) PRIMARY KEY,
    Denofamilia VARCHAR(50) NOT NULL
    CONSTRAINT denofamilia_UK UNIQUE
);

-- TABLA PRODUCTO: => contendr� informaci�n general sobre los productos que 
-- distribuye la empresa a las tiendas.

CREATE TABLE PRODUCTO(
    Codproducto NUMBER(5) PRIMARY KEY,
    Denoproducto VARCHAR(20) NOT NULL,
    Descripcion VARCHAR(100),
    PrecioBase NUMBER (8,2),
    PorcReposicion NUMBER(3),
    UnidadesMinimas NUMBER(4) NOT NULL,
    Codfamilia NUMBER(3) NOT NULL,
    CONSTRAINT precioBase_CK CHECK (PrecioBase > 0),
    CONSTRAINT porReposicion_CK CHECK (PorcReposicion > 0),
    CONSTRAINT unidadesMinimas_CK CHECK (UnidadesMinimas > 0),
    CONSTRAINT codFamilia_FK FOREIGN KEY (Codfamilia) REFERENCES FAMILIA
);

-- TABLA TIENDA: => contendr� informaci�n b�sica sobre las tiendas que 
-- distribuyen los productos.

CREATE TABLE TIENDA(
    Codtienda NUMBER(3) PRIMARY KEY,
    Denotienda VARCHAR(20) NOT NULL,
    Telefono VARCHAR(11),
    CodigoPostal VARCHAR(5) NOT NULL,
    Provincia VARCHAR(5) NOT NULL
);

-- TABLA STOCK: => Contendr�, para cada tienda, el n�mero de unidades 
-- disponibles de cada producto. La clave primaria est� formada por la 
-- concatenaci�n de los campos Codtienda y Codproducto.

CREATE TABLE STOCK(
    Codtienda NUMBER(3) NOT NULL,
    CodProducto NUMBER(5) NOT NULL,
    Unidades NUMBER(6) NOT NULL,
    CONSTRAINT unidades_CK CHECK (Unidades > 0),
    CONSTRAINT codtienda_FK FOREIGN KEY (Codtienda) REFERENCES TIENDA,
    CONSTRAINT codproducto_FK FOREIGN KEY (Codproducto) REFERENCES PRODUCTO,
    CONSTRAINT codigo_PK PRIMARY KEY (Codtienda, Codproducto)
);
